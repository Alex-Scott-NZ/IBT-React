// /app/[lang]/layouts/BaseLayoutNoSideBars.tsx
import React, { ReactNode } from 'react';
import TopBar from '../components/TopBar';
import BottomBar from '../components/BottomBar';
import Header from '../components/Header';
import { GetGlobalSettingsQuery } from '../../../gql/gql-generated';
import NavigationMenu from '../components/NavigationMenu';
import SiteWideNotice from '../components/SiteWideNotice';

interface BaseLayoutNoSideBarsProps {
  globalSettings: GetGlobalSettingsQuery['globalSettings'];
  children: ReactNode; // Changed from children to mainContent to match usage
  lang: string;
}

const BaseLayoutNoSideBars: React.FC<BaseLayoutNoSideBarsProps> = ({
  globalSettings,
  children, // Changed from children to mainContent
  lang
}) => {
  return (
    <div className="bg-custom-bg min-h-screen flex flex-col">
      <TopBar />
      <div className="w-full max-w-[1108px] mx-auto pl-2 pr-2 flex-grow flex flex-col">
        <Header globalSettings={globalSettings} lang={lang} />
        <NavigationMenu lang={lang} />
        <SiteWideNotice 
          notificationData={globalSettings?.fGGlobalSettings?.notificationBar}
        />
        <div className="flex flex-col lg:flex-row lg:justify-between pt-2 lg:pt-2">
          <main className="w-full lg:w-[100%] bg-custom-bg lg:pt-2 p-0 overflow-y-auto mb-4">
            {children} {/* Changed from children to mainContent */}
          </main>
        </div>
      </div>
      <BottomBar />
    </div>
  );
};

export default BaseLayoutNoSideBars;